/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack pilaMoneda=new Stack();
        System.out.print(pilaMoneda.leerUltimoNodo());
        pilaMoneda.agregarNodo(new Nodo(100));
        pilaMoneda.agregarNodo(new Nodo(200));
        pilaMoneda.agregarNodo(new Nodo(300));
        pilaMoneda.agregarNodo(new Nodo(400));
        System.out.println(pilaMoneda.leerUltimoNodo());
        System.out.println(pilaMoneda.removerUltimoNodo());
        System.out.println(pilaMoneda.removerUltimoNodo());
        System.out.println(pilaMoneda.removerUltimoNodo());
        System.out.println(pilaMoneda.removerUltimoNodo());
        
        System.out.println("");
        pilaMoneda.push(400);
        pilaMoneda.push(800);
        pilaMoneda.push(1200);
        pilaMoneda.push(1600);
        pilaMoneda.push(2000);
        pilaMoneda.push(2400);
        System.out.println("");
        pilaMoneda.pop();
        System.out.println("El pop fue: "+pilaMoneda.pop());
        
    
        // TODO code application logic here
    }
    
}
class Nodo{
    private int iVal;
    private Nodo nPrev;
    private Nodo nSig;
    public Nodo(){
        iVal=0;
        nPrev=null;
        nSig=null;
    }
    public Nodo(int iNum){
        iVal=iNum;
        nPrev=null;
        nSig=null;
    }
    public Nodo(int iNum, Nodo nNod){
        iVal=iNum;
        nSig=nNod;
    }

    public int getiVal() {
        return iVal;
    }

    public void setiVal(int iVal) {
        this.iVal = iVal;
    }

    public Nodo getnPrev() {
        return nPrev;
    }

    public void setnPrev(Nodo nPrev) {
        this.nPrev = nPrev;
    }

    public Nodo getnSig() {
        return nSig;
    }

    public void setnSig(Nodo nSig) {
        this.nSig = nSig;
    }
}
class Stack{
Nodo nIni;
    Nodo nFin;
    public Stack(){
        nIni=null;
        nFin=null;
    }
    public Stack(Nodo nNodo){
        nIni=nNodo;
        nFin=nNodo;
    }
     public void agregarNodo(Nodo nNodo){ //AGREGAR NODO AL FINAL
        if(nIni==null){//LISTA VACIA
            nIni=nNodo;
            nFin=nNodo;
        }else{
            nFin.setnSig(nNodo);
            nNodo.setnPrev(nFin);
            nFin=nNodo;
        }
    }
     public int leerUltimoNodo(){
         int iVal=0;
         if(nIni==null){
             System.out.println("LISTA VACIA");
         }else{
             iVal=nFin.getiVal();
         }
         return iVal;
     }
     public int removerUltimoNodo(){
         int iVal=0;
         if(nIni==null){
             System.out.println("LISTA VACIA");
         }else{
             iVal=nFin.getiVal();
             if(nFin.getnPrev()==null){//VERIFICAR CANTIDAD DE NODOS
                 nIni=null;
                 nFin=null;
             }else{
                 nFin=nFin.getnPrev();
                 nFin.setnSig(null);
             }
         }
         return iVal;
     }
     public void imprimirElementos(){
         if(nIni==null){
            System.out.println("LISTA VACIA");
        }else{
        Nodo nTemp=nIni;
        while(nTemp!=null){
            System.out.print(nTemp.getiVal()+" - ");
            nTemp=nTemp.getnSig();
        }
        }
     }
     public void push (int iVal){
         int iCont=0;
         Nodo nNodo=new Nodo(iVal);
         nNodo.setnSig(nNodo);
         System.out.println(nNodo.getiVal());
         if(nIni==null){
             nIni=nNodo;
             nFin=nNodo;
         }else{
             nFin.setnSig(nNodo);
             nFin=nNodo;
         }
         iCont++;
     }
     public int pop(){
         int iCont=0;
         int nTemp=nFin.getiVal();
         System.out.println(nFin.getiVal());
         if(nIni==nFin){
             nIni=null;
             nFin=null;
         }else{
             nFin.setnSig(nIni);
         }
         iCont--;
         return nTemp;
     }
}

