/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for (int i = 5; i >=1; i--) {
            System.out.println("i= "+i);
        }
        falsoFor(5);
        falsoForUp(1,5);
        // TODO code application logic here
    }
    public static void falsoFor(int iVal){
        System.out.println(iVal+"-");
        if(iVal>1)
        falsoFor(iVal-1);
    }
    public static void falsoForUp(int iIni, int iFin){
        System.out.println(iIni+" - ");
        if(iIni<iFin)
            falsoForUp(iIni+1, iFin);
    }
    
}
