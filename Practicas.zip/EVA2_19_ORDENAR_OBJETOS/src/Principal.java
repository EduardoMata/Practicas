
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LinkedList <Persona> llPersonas=new LinkedList();
        llPersonas.add(new Persona("Eduardo","Mata",19, true,1));
        llPersonas.add(new Persona("Esmeralda","Gomez",17, false,8250));
        llPersonas.add(new Persona("Bryan","Gutierrez",20, true,92250));
        llPersonas.add(new Persona("Karla","Hernan",21, false,55));
        llPersonas.add(new Persona("Ottmar","Rivera",22, true,2550));
        for (Persona llPersona : llPersonas) {
            System.out.println("Nombre: "+llPersona.getNombre()+"\n"+
                    "Apellido: "+llPersona.getApellido()+"\n"+
                    "Edad: "+llPersona.getEdad()+"\n"+
                    "Sexo: "+llPersona.isSexo()+"\n"+
                    "Salario: "+llPersona.getSalario()+"\n");
        }
        //Collections.sort
        Comparator cmCriterioOrden=new Comparator(){
            @Override
            public int compare(Object o1, Object o2) {
               Persona p1=(Persona)o1;
               Persona p2=(Persona)o2;
               String apellido1, apellido2;
               apellido1=p1.getApellido();
               apellido2=p2.getApellido();
               char c1,c2;
               c1=apellido1.charAt(0);
               c2=apellido2.charAt(0);
               return c1-c2;
            }
        
        };
        Comparator cmCriterioEdad=new Comparator(){//COMPARAR Y ORDENAR EDADES
            @Override
            public int compare(Object o1, Object o2) {
                Persona p1=(Persona)o1;
                Persona p2=(Persona)o2;
                int edad1,edad2;
                edad1=p1.getEdad();
                edad2=p2.getEdad();
                return edad1-edad2;

            }
        };
        Comparator cmCriterioSalario=new Comparator(){ //COMPARAR Y ORDENAR SALARIOS
            @Override
            public int compare(Object o1, Object o2) {
                 Persona p1=(Persona)o1;
                 Persona p2=(Persona)o2;
                 double salario1,salario2;
                 salario1=(int)p1.getSalario();
                 salario2=(int)p2.getSalario();
                 return (int)(salario1-salario2);
            }
        };
        Collections.sort(llPersonas, cmCriterioOrden);
         for (Persona llPersona : llPersonas) {
            System.out.println("Nombre: "+llPersona.getNombre()+"\n"+
                    "Apellido: "+llPersona.getApellido()+"\n"+
                    "Edad: "+llPersona.getEdad()+"\n"+
                    "Sexo: "+llPersona.isSexo()+"\n"+
                    "Salario: "+llPersona.getSalario()+"\n");
        }
         Collections.sort(llPersonas, cmCriterioEdad);
         for (Persona llPersona : llPersonas) {
            System.out.println("Nombre: "+llPersona.getNombre()+"\n"+
                    "Apellido: "+llPersona.getApellido()+"\n"+
                    "Edad: "+llPersona.getEdad()+"\n"+
                    "Sexo: "+llPersona.isSexo()+"\n"+
                    "Salario: "+llPersona.getSalario()+"\n");
        }
    }
    
}
class Persona{
    private String nombre;
    private String apellido;
    private int edad;
    private boolean sexo;
    private double salario;

    public Persona(String nombre, String apellido, int edad, boolean sexo, double salario) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.sexo = sexo;
        this.salario = salario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public boolean isSexo() {
        return sexo;
    }

    public void setSexo(boolean sexo) {
        this.sexo = sexo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    
         
}
