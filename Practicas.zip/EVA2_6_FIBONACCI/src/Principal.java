/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(Fibonacci(9));
        
        // TODO code application logic here
    }
    
    public static int Fibonacci(int iPos){
        if(iPos==0){
            return 0;
        }
        else if(iPos==1){
                return 1;
        }
        else{
            return Fibonacci(iPos-1)+Fibonacci(iPos-2);
        }
    }
    
}
