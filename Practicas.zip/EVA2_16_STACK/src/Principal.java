
import java.util.Stack;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack <Double>sMiPila=new Stack();
        sMiPila.push(10.0);
        sMiPila.push(20.0);
        sMiPila.push(30.0);
        sMiPila.push(40.0);
        sMiPila.push(50.0);
        System.out.println(sMiPila.pop());
        System.out.println(sMiPila.pop());
        System.out.println(sMiPila.peek());
        System.out.println(sMiPila.pop());
        System.out.println(sMiPila.peek());
        // TODO code application logic here
    }
    
}
