/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Nodo nObji=new Nodo();
        nObji.iVal=100;
        Nodo nObji2=new Nodo();
        nObji2.iVal=200;
        Nodo nObji3=new Nodo();
        nObji3.iVal=300;
        //VINCULAR
        nObji.nSig=nObji2;
        nObji2.nSig=nObji3;
        
       System.out.println(nObji.iVal);
       System.out.println(nObji2.iVal);
       System.out.println(nObji3.iVal);
       
       Nodo nMover=nObji;
       while(nMover!=null){
           System.out.println(nMover.iVal);
           nMover=nMover.nSig;
       }
       
    }
    
}
class Nodo{
    public int iVal;
    public Nodo nSig;
    public Nodo(){
        nSig=null;
    }
}
