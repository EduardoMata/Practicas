/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //for (int i = 1; i <= 10; i++) {
           // System.out.println("Cadena: "+ cadenaRecursiva(i));
        //}
        //for (int i = 9; i >= 1; i--) {
            //System.out.println("Cadena: "+ cadenaRecursiva(i));
        //}
        int i=1;
        int cont=1;
        int iCon=1;
        int bloqueo=1;
      while(i!=0){
          
      }
        // TODO code application logic here
    }
    public static String cadenaRecursiva(int iNum){
        if(iNum>1){
            
            return "*"+cadenaRecursiva(iNum-1);
        }else{
            return "*";
        }
    }
    
}
