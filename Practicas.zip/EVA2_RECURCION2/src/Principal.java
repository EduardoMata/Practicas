/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(EliminarPalabra("xhjas"));
        // TODO code application logic here
    }
    public static String EliminarPalabra(String sPalabra){
        if("".equals(sPalabra)){
            return "";
        }else{
            if(("x").equals(sPalabra.charAt(0))){
                return EliminarPalabra(sPalabra.substring(1));
            }else{
                return sPalabra.charAt(0)+EliminarPalabra(sPalabra.substring(1));
            }
                  
        }
    }
           
    
}
