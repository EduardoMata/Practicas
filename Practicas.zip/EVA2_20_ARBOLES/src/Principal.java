
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Arbol arMiArbol=new Arbol();
        try {
            arMiArbol.agregarNuevoNodo(new Nodo(100));
            arMiArbol.agregarNuevoNodo(new Nodo(101));
            arMiArbol.agregarNuevoNodo(new Nodo(97));
            arMiArbol.agregarNuevoNodo(new Nodo(80));
            arMiArbol.agregarNuevoNodo(new Nodo(115));
            arMiArbol.agregarNuevoNodo(new Nodo(114));
            arMiArbol.imprimirPreOrder();
            // TODO code application logic here
        } catch (Exception ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
}
 class Nodo{
        private int iVal;
    private Nodo nIzq;
    private Nodo nDer;
    public Nodo(){
        iVal=0;
        nIzq=null;
        nDer=null;
    }
    public Nodo(int iNum){
        iVal=iNum;
        nIzq=null;
        nDer=null;
    }
    public Nodo(int iNum, Nodo nNod){
        iVal=iNum;
        nDer=nNod;
    }

    public int getiVal() {
        return iVal;
    }

    public void setiVal(int iVal) {
        this.iVal = iVal;
    }

    public Nodo getnIzq() {
        return nIzq;
    }

    public void setnIzq(Nodo nPrev) {
        this.nIzq = nIzq;
    }

    public Nodo getnDer() {
        return nDer;
    }

    public void setnDer(Nodo nSig) {
        this.nDer = nDer;
    }
    

    }
    class Arbol{
        private Nodo nRoot;
        public Arbol(){
            nRoot=null;
        }
        public Arbol(Nodo nNodo){
            nRoot=nNodo;
        }
        public void agregarNuevoNodo(Nodo nNodo) throws Exception{
            agregarNodo(nRoot, nNodo);
        }
        public void agregarNodo(Nodo nActual, Nodo nNodo) throws Exception{
            if(nRoot==null){
                nRoot=nNodo;
            }else{
                if(nNodo.getiVal()<nActual.getiVal()){
                    if(nActual.getnIzq()==null){
                        nActual.setnIzq(nNodo);
                    }else{
                        agregarNodo(nActual.getnIzq(), nNodo);
                    }
                }else if(nNodo.getiVal()>nActual.getiVal()){
                     if(nActual.getnDer()==null){
                        nActual.setnDer(nNodo);
                    }else{
                        agregarNodo(nActual.getnDer(), nNodo);
                    }
                }else {
                    throw new Exception ("NO SE ACEPTAN VALORES REPETIDOS");                    
                }
            }
        }
        public void imprimirPreOrder(){
            impPO(nRoot);
        }
        public void impPO(Nodo nActual){
            if(nActual != null){
                System.out.print(nActual.getiVal()+" - ");
                impPO(nActual.getnIzq());//Recorrer lado izquierdo
                impPO(nActual.getnDer());//Recorrer lado derecho
            }
        }
        public void impPOST(Nodo nActual){
            if(nActual!=null){
                impIN(nActual.getnIzq());
                impIN(nActual.getnDer());
                System.out.println(nActual.getiVal()+" - ");
            }
        }
        public void imprimirPostOrder(){
            impPOST(nRoot);
        }
        public void impIN(Nodo nActual){
            if(nActual!=null){
                impIN(nActual.getnIzq());
                System.out.println(nActual.getiVal());
                impIN(nActual.getnDer());
            }
        }
        public void imprimirInOrder(){
            impIN(nRoot);
        }
    }
