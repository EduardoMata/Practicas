/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Queue qFilaSuper=new Queue();
        qFilaSuper.leerPrimerNodo();
        qFilaSuper.agregarNodo(new Nodo(100));
        qFilaSuper.agregarNodo(new Nodo(200));
        qFilaSuper.agregarNodo(new Nodo(300));
        qFilaSuper.agregarNodo(new Nodo(400));
        System.out.println("El tamaño de la pila es "+qFilaSuper.tamaño());
        System.out.println(qFilaSuper.leerPrimerNodo());
        System.out.println(qFilaSuper.removerPrimerNodo());
        System.out.println(qFilaSuper.removerPrimerNodo());
        System.out.println(qFilaSuper.removerPrimerNodo());
        System.out.println(qFilaSuper.removerPrimerNodo());
        System.out.println(qFilaSuper.removerPrimerNodo());
        
        // TODO code application logic here
    }
    
}
class Nodo{
    private int iVal;
    private Nodo nPrev;
    private Nodo nSig;
    public Nodo(){
        iVal=0;
        nPrev=null;
        nSig=null;
    }
    public Nodo(int iNum){
        iVal=iNum;
        nPrev=null;
        nSig=null;
    }
    public Nodo(int iNum, Nodo nNod){
        iVal=iNum;
        nSig=nNod;
    }

    public int getiVal() {
        return iVal;
    }

    public void setiVal(int iVal) {
        this.iVal = iVal;
    }

    public Nodo getnPrev() {
        return nPrev;
    }

    public void setnPrev(Nodo nPrev) {
        this.nPrev = nPrev;
    }

    public Nodo getnSig() {
        return nSig;
    }

    public void setnSig(Nodo nSig) {
        this.nSig = nSig;
    }
    
}
class Queue{
    Nodo nIni;
    Nodo nFin;
    public Queue(){
        nIni=null;
        nFin=null;
    }
    public Queue(Nodo nNodo){
        nIni=nNodo;
        nFin=nNodo;
    }
     public void agregarNodo(Nodo nNodo){ //AGREGAR NODO AL FINAL
        if(nIni==null){//LISTA VACIA
            nIni=nNodo;
            nFin=nNodo;
        }else{
            nFin.setnSig(nNodo);
            nNodo.setnPrev(nFin);
            nFin=nNodo;
        }
    }
     public int leerPrimerNodo(){
         int iVal=0;
         if(nIni==null){
             System.out.println("LISTA VACIA");
         }else{
             iVal=nIni.getiVal();
         }
         return iVal;
     }
     public int removerPrimerNodo(){
         int iVal=0;
         if(nIni==null){
             System.out.println("LISTA VACIA");
         }else{
             iVal=nIni.getiVal();
             if(nIni.getnSig()==null){//VERIFICAR CANTIDAD DE NODOS
                 nIni=null;
                 nFin=null;
             }else{
                 nIni=nIni.getnSig();
                 nIni.setnPrev(null);
             }
         }
         return iVal;
     }
     public void imprimirPila(){
         Nodo nTemp=nIni;
        if(nIni==null){
            System.out.println("LISTA VACIA");
        }else{
            while(nTemp.getnSig()!=null){
                System.out.print(nTemp.getiVal()+" - ");
                nTemp=nTemp.getnSig();
            }
            
        }
        
    }
     public int tamaño(){ //Calcular el tamaño de la lista
         int iCont=0;
         Nodo nTemp=new Nodo(); //Nodo temporal
         nTemp=nIni;
         while(nTemp.getnSig()!=null){
             nTemp=nTemp.getnSig();
             iCont++;
         }
         return iCont+1;
     }
     public void estaVacia(){
         if(nIni==null){
             System.out.println("La lista está vacía");
         }else{
             System.out.println("La lista no está vacía");
         }
     }
     
}