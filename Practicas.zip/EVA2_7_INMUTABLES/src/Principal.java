/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int aiDatos[]=new int[3];
        aiDatos[0]=5;
        aiDatos[1]=6;
        aiDatos[2]=7;
        int aiBackup[]=new int[3];
        
        int i=0;    
        for (int aiDato : aiDatos) {
            System.out.println(aiDato);
            aiBackup[i]=aiDato;
            i++;
        }
        aiDatos=new int[4];
        for (int j = 0; j < aiBackup.length; j++) {
            aiDatos[i]=aiDatos[j];
        }
        for (int aiDato : aiDatos) {
            System.out.println(aiDato);
        }
        // TODO code application logic here
    }
    
}
