
import java.util.ArrayList;
import java.util.Iterator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList <Integer> aiMiArrayList=new ArrayList();
        aiMiArrayList.add(100);
        aiMiArrayList.add(200);
        aiMiArrayList.add(300);
        aiMiArrayList.add(400);
        aiMiArrayList.add(500);
        for (Integer aiMiArrayList1 : aiMiArrayList) {
            System.out.print(aiMiArrayList1+"-");
        }
        aiMiArrayList.add(2,999);
        System.out.println("");
        for (Integer aiMiArrayList1 : aiMiArrayList) {
            System.out.print(aiMiArrayList1+"-");
        }
        System.out.println("");
        //RECORRER UN COLLECTION CON ITERADORES
        Iterator itRecorrerArray = aiMiArrayList.iterator();
        while(itRecorrerArray.hasNext()){
            System.out.print(itRecorrerArray.next()+"-");
                    
                   
        }
    }
    
}
