/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(sinRepeticiones("hhhhaaa"));
        System.out.println(sinRepeticiones("sssollloo"));
        System.out.println(sinRepeticiones("eexxttasiiis"));
        System.out.println(sinRepeticiones("ppoookkkemmmon"));
        System.out.println(sinRepeticiones("hahahaha"));
              
        // TODO code application logic here
    }
    public static String sinRepeticiones(String sWord){ //LIMPIAR CADENA
        if(sWord.length()==1){
            return sWord;
        }else if(sWord.charAt(0)==sWord.charAt(1)){ //Evalua el siguiente caracter
            return sinRepeticiones(sWord.substring(1)); //Si el caracter siguiente es igual, repite el metodo sin ese caracter
            
        }else{
         return sWord.charAt(0)+sinRepeticiones(sWord.substring(1));
        }
    }
}
