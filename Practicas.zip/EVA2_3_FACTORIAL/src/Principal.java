/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Factorial de 5 es: "+falsoFor(5));
        
    }
    public static int falsoFor(int iCond){ //Metodo obtener factorial
        if(iCond>0){
            return iCond*falsoFor(iCond-1);
        } else{
            return 1;
        }
            
            
    }
    
}
