/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaDE miLista=new ListaDE();
        miLista.imprimirElementos();
        miLista.imprimirElementosInv();
        System.out.println("");
        for (int i = 0; i < 10; i++) {
            miLista.agregarNodo(new Nodo((int)(Math.random()*100)+1));
        }
        miLista.imprimirElementos();
        System.out.println("");
        miLista.imprimirElementosInv();
        System.out.println("");
        miLista.contarElementos();
        System.out.println("");
        miLista.insertarEn(2, new Nodo(60));
        miLista.imprimirElementos();
        System.out.println("");
        miLista.buscarEn(60);
        System.out.println("");
        miLista.borrarEn(2);
        miLista.imprimirElementos();
        miLista.vaciar();
        System.out.println("");
        miLista.imprimirElementos();
        // TODO code application logic here
    }
    
}
class Nodo{
    private int iVal;
    private Nodo nPrev;
    private Nodo nSig;
    public Nodo(){
        iVal=0;
        nPrev=null;
        nSig=null;
    }
    public Nodo(int iNum){
        iVal=iNum;
        nPrev=null;
        nSig=null;
    }
    public Nodo(int iNum, Nodo nNod){
        iVal=iNum;
        nSig=nNod;
    }

    public int getiVal() {
        return iVal;
    }

    public void setiVal(int iVal) {
        this.iVal = iVal;
    }

    public Nodo getnPrev() {
        return nPrev;
    }

    public void setnPrev(Nodo nPrev) {
        this.nPrev = nPrev;
    }

    public Nodo getnSig() {
        return nSig;
    }

    public void setnSig(Nodo nSig) {
        this.nSig = nSig;
    }
    
}
class ListaDE{
    Nodo nIni;
    Nodo nFin;
    public ListaDE(){
        nIni=null;
        nFin=null;
    }
    public ListaDE(Nodo nNodo){
        nIni=nNodo;
        nFin=nNodo;
    }
    public void agregarNodo(Nodo nNodo){ //AGREGAR NODO AL FINAL
        if(nIni==null){
            nIni=nNodo;
            nFin=nNodo;
        }else{
            nFin.setnSig(nNodo);
            nNodo.setnPrev(nFin);
            nFin=nNodo;
        }
    }
    public void imprimirElementos(){
        if(nIni==null){
            System.out.println("LISTA VACIA");
        }else{
        Nodo nTemp=nIni;
        while(nTemp!=null){
            System.out.print(nTemp.getiVal()+" - ");
            nTemp=nTemp.getnSig();
        }
        }
    }
    public void imprimirElementosInv(){
        if(nIni==null){
            System.out.println("LISTA VACIA");
        }else{
        Nodo nTemp=nFin;
        while(nTemp!=null){
            System.out.print(nTemp.getiVal()+" - ");
            nTemp=nTemp.getnPrev();
        }
        }
    }
    public int contarElementos(){
        Nodo nTemp=nIni;
        if(nIni==null){
            return 0;
        }else{
            int iCon=0;
            while(nTemp.getnSig()!=null){
                iCon++;
                nTemp=nTemp.getnSig();
            }
            return iCon;
        }
    }
    public void borrarEn(int iPos){
        if(iPos==0){
            nIni=nIni.getnSig();
        }else{
            Nodo nTemp=nIni;
            for (int i = 0; i < (iPos-1); i++) {
                nTemp=nTemp.getnSig();
            }
            nTemp.setnSig(nTemp.getnSig().getnSig());
            nTemp.getnSig().setnPrev(nTemp.getnPrev());
            
        }
    }
    public void buscarEn(int iBus){
        Nodo nTemp=nIni;
        int iCon=0;
        int iPos=0;
        while(iCon==0){
       
            nTemp=nTemp.getnSig();
            if(nTemp.getiVal()==iBus){
                System.out.print("La primera aparición está en la posición "+(iPos+1));
                iCon=1;
            }
            iPos++;
            
        
        }
    }
    public void insertarEn(int iPos, Nodo nNodo){
        //VERIFICAR IPOS>=0, IPOS< TAMAÑO DE LA LISTA
        //INSERTAR AL INICIO DE LA LISTA:
        if(iPos>=0){
        if(iPos==0){
            nNodo.setnSig(nIni);
            nIni=nNodo;
            nIni.getnSig().setnPrev(nNodo);
     
    }else{
            Nodo nTemp=nIni;
            for (int i = 0; i < (iPos-1); i++) {
                nTemp=nTemp.getnSig();
                
            }
            if(nTemp!=null){
            nNodo.setnSig(nTemp.getnSig());
            nTemp.setnSig(nNodo);
            nNodo.setnPrev(nTemp.getnPrev());
            }else{
                System.out.println("La lista no es tan grande");
            }
            
        }
        }else{
            System.out.println("El valor no puede ser insertado");
        }
                
        //INSERTAR EN CUALQUIER POSICIÓN DE LA LISTA
       
    }
    public void vaciar(){
        nIni=null;
    }
}