/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Maximo comun divisor: "+GCD(23,0));
        // TODO code application logic here
    }
    public static int GCD (int iDiv, int iDivi){
        int iResi;
        if(iDivi==0){
            return iDiv;
        }else{
            iResi=iDiv%iDivi;
            return GCD(iDivi,iResi);
        }
    }
    
}
