/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ed
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Limpio: "+eliminarCarac("(((Njaskda)))))"));
        // TODO code application logic here
    }
    public static boolean eliminarCarac(String iWord){
        if(iWord.equals("")){
            return true;
        }else if(iWord.charAt(0)=='('&&iWord.charAt(iWord.length()-1)==')'){
            return eliminarCarac(iWord.substring(1,iWord.length()-1));
        }else{
            return false;
        }
    }
    
}
